
//blod bank package

package blood.bank;


public class DonorInformation {
   private String DonorID;
   public String Name;
   public String BloodGroup;
   public String PNO;
   public String Gender;
   public String Address;

    public DonorInformation(String DonorID, String Name, String BloodGroup, String PNO, String Gender, String Address) {
        this.DonorID = DonorID;
        this.Name = Name;
        this.BloodGroup = BloodGroup;
        this.PNO = PNO;
        this.Gender = Gender;
        this.Address = Address;
    }
    
    @Override
    public String toString () {
        String details = "Donor ID is " + this.DonorID + "\nName is " + this.Name + "\nBlood Group is " + this.BloodGroup + "\nContact number is " + this.PNO + "\nGender is " + this.Gender + "\nAddress is " + this.Address;
        return details;
    }
}
