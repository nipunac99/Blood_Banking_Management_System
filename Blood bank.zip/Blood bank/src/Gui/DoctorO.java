// package GUI
package Gui;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author User User
 */
public class DoctorO {
    private String name;
    private  String id;
    private String address;
    private String gender;
    private String phoneNo;

    public DoctorO(String name, String id, String address, String gender, String phoneNo) {
        this.name = name;
        this.id = id;
        this.address = address;
        this.gender = gender;
        this.phoneNo = phoneNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    @Override
    public String toString() {
        return "DoctorO{" + "name=" + name + ", id=" + id + ", address=" + address + ", gender=" + gender + ", phoneNo=" + phoneNo + '}';
    }
    
    
    
}
