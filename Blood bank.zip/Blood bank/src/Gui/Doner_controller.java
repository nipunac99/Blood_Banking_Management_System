// package gui
package Gui;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import patientregistersystem.DBConnection;

public class Doner_controller {
    public static  boolean addDonor(Donor1 donor)throws ClassNotFoundException, SQLException{
           PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Insert into donor Values(?,?,?,?,?,?,?)");
           stm.setObject(1, donor.getId());
       stm.setObject(2, donor.getName());
       stm.setObject(3, donor.getBGroup());
       stm.setObject(4, donor.getAddress());
       stm.setObject(5, donor.getPNO());
       stm.setObject(6, donor.getAge());
       stm.setObject(7, donor.getGender());
       return stm.executeUpdate()>0;
           
    
    
    }
    
    public static boolean deleteDonor(String id) throws ClassNotFoundException, SQLException {
        return DBConnection.getInstance().getConnection().createStatement().executeUpdate("delete from donor where ='"+id+"'")>0;
    }
    
    public static boolean updateDonor(Donor1 donor1) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Update donor SET Doner_Name=?, Blood_Group=?, Address=?,P_NO=?,Age=?,Gender=? where Donor_ID=?");
      
        stm.setObject(1, donor1.getId());
       stm.setObject(2, donor1.getName());
       stm.setObject(3, donor1.getBGroup());
       stm.setObject(4, donor1.getAddress());
       stm.setObject(5, donor1.getPNO());
       stm.setObject(6, donor1.getAge());
       stm.setObject(7, donor1.getGender());
       return stm.executeUpdate()>0;
    }
    
    
    
}
