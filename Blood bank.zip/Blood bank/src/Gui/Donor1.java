// package GUI
package Gui;


public class Donor1 {
    private  String Id;
    private String   Name;
    private String   BGroup;
   private String    Address;
     private String  PNO;
   private int    Age;
   private String Gender;
   
    public Donor1( String Id,String   Name,String   BGroup,String    Address,String  PNO ,int    Age ,String Gender)
    {
        this.Id= Id;
        this.Name=Name;
        this.BGroup=BGroup;
        this.Address=Address;
        this.PNO=PNO;
        this.Age=Age;
        this.Gender=Gender;
        
        
    }

    Donor1(String text, String text0, String text1, String string, String text2, String text3, int parseInt, String gender) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   public String getId(){
return Id;
}
   
   public void setId(String Id){
        this.Id = Id;
    }
   public String getName(){
return Name;
}
   
   public void setName(String Name){
        this.Name = Name;
    }
   public String getBGroup(){
return BGroup;
}
   
   public void setBGroup(String BGroup){
        this.BGroup = BGroup;
    }
   public String getAddress(){
return Address;
}
   
   public void setAddress(String Address){
        this.Address = Address;
    }
   public String getPNO(){
return PNO;
}
   
   public void setPNO(String PNO){
        this.PNO = PNO;
    }
   public int getAge(){
    return Age;
}
   
   public void setAge(int Age){
        this.Age = Age;
    }
   public String getGender(){
return Gender;
}
   
   public void setGender(String Gender){
        this.Gender = Gender;
    }
   
   @Override
   public String toString() {
       
        return "Donor1{" + "Id=" + Id + ", Name=" + Name + ", BGroup=" + BGroup + ", Address=" + Address + ", PNO=" + PNO +",Age"+Age+",Gender="+Gender+ '}';
    
    }
}
