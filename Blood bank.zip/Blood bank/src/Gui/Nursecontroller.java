// package GUI
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import patientregistersystem.DBConnection;

public class Nursecontroller {
   
     public static boolean addNurse(Nurseo nurseo) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Insert into nurse  Values(?,?,?,?)");
       stm.setObject(1, nurseo.getNurseId());
       stm.setObject(2, nurseo.getName());
       stm.setObject(3, nurseo.getGender());
       stm.setObject(4, nurseo.getPNO());
       
       return stm.executeUpdate()>0;
    }
       public static boolean deleteNurse(String nurse_ID) throws ClassNotFoundException, SQLException {
        return DBConnection.getInstance().getConnection().createStatement().executeUpdate("delete from nurse where ='"+nurse_ID+"'")>0;
    }
     
     
     
     public static boolean updateNurse(Nurseo nurseo) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Update nurse SET Nurse_name=?,  Gender=?,P_NO=? where nurse_ID=?");
      
        stm.setObject(1, nurseo.getNurseId());
       stm.setObject(2, nurseo.getName());
       stm.setObject(3, nurseo.getGender());
       stm.setObject(4, nurseo.getPNO());
       return stm.executeUpdate()>0;
    }
    
}

