/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

/**
 *
 * @author HP
 */
public class DonorInformation {
    String DonorID;
    String Name;
    String BloodGroup;
    String PNO;
    String Gender;
    String Address;

    public DonorInformation(String DonorID, String Name, String BloodGroup, String PNO, String Gender, String Address) {
        this.DonorID = DonorID;
        this.Name = Name;
        this.BloodGroup = BloodGroup;
        this.PNO = PNO;
        this.Gender = Gender;
        this.Address = Address;
    }
    
    @Override
    public String toString()    {
        String details = null;
        return details;
    }
}
