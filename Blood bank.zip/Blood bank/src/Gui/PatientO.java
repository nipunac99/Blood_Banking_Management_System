// package GUI
package Gui;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kavindu
 */
public class PatientO {
    private String Name;
    private String gender;
    private String nic;
    private String dob;
    private String address;
    private String email;
    private String bloodgroup;
    private int pno;
    

    public PatientO() {
    }

    public PatientO(String Name,  String gender, String nic, String dob, String address, String email, String bloodgroup, int pno  ) {
        
        this.Name =Name;
        this.gender = gender;
        this.nic = nic;
        this.dob = dob;
        this.address = address;
        this.email = email;
        this.bloodgroup = bloodgroup;
        this.pno = pno;
        
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

   

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public int getPno() {
        return pno;
    }

    public void setPno(int pno) {
        this.pno = pno;
    }
@Override
    public String toString() {
        return "PatientO{" + "name=" + Name + ", Gender=" + gender + ", NIC=" + nic + ", dob=" + dob + ", address=" + address +",email"+email+",bloodgroup"+bloodgroup+
        "pno="+pno+'}';
    }

   


    
    
    
}
