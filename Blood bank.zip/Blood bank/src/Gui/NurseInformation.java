// package GUI
package Gui;


public class NurseInformation {
    String NurseID;
    String Name;
    String Gender;
    int PNO;

    public NurseInformation(String NurseID, String Name, String Gender, int PNO) {
        this.NurseID = NurseID;
        this.Name = Name;
        this.Gender = Gender;
        this.PNO = PNO;
    }



    
    
    
    
    
    @Override
    public String toString ()   {
        String details = null;
        return details;
    }
    
}
