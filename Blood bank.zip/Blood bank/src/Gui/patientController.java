// package GUI
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import patientregistersystem.DBConnection;



public class patientController {
    
       public static boolean addPatient(PatientO patiento) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Insert into patient Values(?,?,?,?,?,?,?,?)");
       stm.setObject(1, patiento.getName());
       stm.setObject(2, patiento.getGender());
       stm.setObject(3, patiento.getNic());
       stm.setObject(4, patiento.getDob());
       stm.setObject(5, patiento.getAddress());
       stm.setObject(6, patiento.getEmail());
       stm.setObject(7, patiento.getBloodgroup());
       stm.setObject(8, patiento.getPno());



       return stm.executeUpdate()>0;
    }
    
        public static boolean deletePatient(String nic) throws ClassNotFoundException, SQLException {
        return DBConnection.getInstance().getConnection().createStatement().executeUpdate("delete from patient where ='"+nic+"'")>0;
    }
        
        
         public static boolean updatePatient(PatientO patiento) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Update patient SET patiet_name=?,  Gender=?,DOB=?,Addrss=?,Email=?,Blood_Group=?,P_NO=? where NIC=?");
      
       stm.setObject(1, patiento.getName());
       stm.setObject(2, patiento.getGender());
       stm.setObject(3, patiento.getNic());
       stm.setObject(4, patiento.getDob());
       stm.setObject(5, patiento.getAddress());
       stm.setObject(6, patiento.getEmail());
       stm.setObject(7, patiento.getBloodgroup());
       stm.setObject(8, patiento.getPno());
       return stm.executeUpdate()>0;
    }
}
