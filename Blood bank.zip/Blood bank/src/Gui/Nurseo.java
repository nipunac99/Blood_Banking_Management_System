// package GUI
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

/**
 *
 * @author User User
 */
public class Nurseo {
  private String NurseID;
    private String Name;
    private String Gender;
    private int PNO;
  

public Nurseo(String NurseID, String Name, String Gender, int PNO) {
        this.NurseID = NurseID;
        this.Name = Name;
        this.Gender = Gender;
        this.PNO =PNO ;
        
}
   public String getNurseId() {
        return NurseID;
    }

    public void setNurseID(String NurseID) {
        this.NurseID = NurseID;
    }
 public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
     public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }
 public int getPNO() {
        return PNO;
    }

    public void setPNO(int PNO){
        this.PNO = PNO;
    }
@Override
 public String toString() {
        return "Nurseo{" + "NurseID=" + NurseID + ", Name=" + Name + ", Gender=" + Gender + ", PNO" + PNO +  '}';
    }
} 