// package GUI
package Gui;


public class DoctorInformation {
    String Name;
    String DoctorID;
    String Address;
    String Gender;
    String PNO;

    public DoctorInformation(String Name, String DoctorID, String Address, String Gender, String PNO) {
        this.Name = Name;
        this.DoctorID = DoctorID;
        this.Address = Address;
        this.Gender = Gender;
        this.PNO = PNO;
    }
    
    @Override
    public String toString ()   {
        String details = null;
        return details;
    }
}
