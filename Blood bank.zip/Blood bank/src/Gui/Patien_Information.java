// package GUI
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

public class Patien_Information {
    
    private String Name;
    private String gender;
    private String nic;
    private String dob;
    private String address;
    private String email;
    private String bloodgroup;
    private int pno;
    
    
    
     public Patien_Information(String Name,  String gender, String nic, String dob, String address, String email, String bloodgroup, int pno  ) {
        
        this.Name =Name;
        this.gender = gender;
        this.nic = nic;
        this.dob = dob;
        this.address = address;
        this.email = email;
        this.bloodgroup = bloodgroup;
        this.pno = pno;
        
    }
     @Override
        public String toString ()   {
        String details = null;
        return details;
    }
     
     
     
     
     
     
}



