// package GUI
package Gui;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import Gui.DoctorO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import patientregistersystem.DBConnection;

/**
 *
 * @author User User
 */
public class DoctorController {
     public static boolean addDoctor(DoctorO doctorO) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Insert into blood_doctor Values(?,?,?,?,?)");
       stm.setObject(1, doctorO.getId());
       stm.setObject(2, doctorO.getName());
       stm.setObject(3, doctorO.getAddress());
       stm.setObject(4, doctorO.getGender());
       stm.setObject(5, doctorO.getPhoneNo());
       return stm.executeUpdate()>0;
    }
  

    public static boolean deleteDoctor(String id) throws ClassNotFoundException, SQLException {
        return DBConnection.getInstance().getConnection().createStatement().executeUpdate("delete from blood_doctor where ='"+id+"'")>0;
    }

   public static boolean updateDoctor(DoctorO doctorO) throws ClassNotFoundException, SQLException {
       PreparedStatement stm = DBConnection.getInstance().getConnection().prepareStatement("Update blood_doctor SET Doctor_Name=?, Address=?, Gender=?,p_No=? where Doctor_ID=?");
      
       stm.setObject(1, doctorO.getId());
       stm.setObject(5, doctorO.getName());
       stm.setObject(2, doctorO.getAddress());
       stm.setObject(3, doctorO.getGender());
       stm.setObject(4, doctorO.getPhoneNo());
       return stm.executeUpdate()>0;
    }
    
}
